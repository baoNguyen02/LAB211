/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Win
 */
public class Calculator {
    
    public  int[][] additionMatrix(int[][] matrix1, int[][] matrix2){
        int row = matrix1.length;
        int col = matrix1[0].length;
        int row2 = matrix2.length;
        int col2 = matrix2[0].length;
        if(row != row2 || col != col2) {
            return null;
        }
        int[][] result = new int[row][col];
        //traverse from first element of row to last element of row of matrix
        int i, j;
        for(i = 0; i < row; i++){
            //traverse from first element of column to last element of column of matrix
            for (j = 0; j < col; j++) {
                result[i][j] = matrix1[i][j] + matrix2[i][j];
                // result[0][0] =  matrix1[0][0] + matrix2[0][0]
                // result[0][1] =  matrix1[0][1] + matrix2[0][1]
                // ...
            }
        }
        return result;
    }
    
    public int[][] subtractionMatrix(int[][] matrix1, int[][] matrix2) {
        int row = matrix1.length;
        int col = matrix1[0].length;
        int row2 = matrix2.length;
        int col2 = matrix2[0].length;
        if(row != row2 || col != col2) {
            return null;
        }
        int[][] result = new int[row][col];
        //traverse from first element of row to last element of row of matrix
        int i, j;
        for (i = 0; i < row; i++) {
            //traverse from first element of column to last element of column of matrix
            for (j = 0; j < col; j++) {
                result[i][j]= matrix1[i][j] - matrix2[i][j];
                // result[0][0] =  matrix1[0][0] - matrix2[0][0]
                // result[0][1] =  matrix1[0][1] - matrix2[0][1]
                // ...
            }
        }
        return result;
    }
    
    public int[][] multiplicationMatrix(int[][] matrix1, int[][] matrix2){
        int rowM1 = matrix1.length;
        int rowM2 = matrix2.length;
        int colM1 = matrix1[0].length;      
        int colM2 = matrix2[0].length;
        
        if(rowM2 != colM1) {
            return null;
        }
        int[][] result = new int[rowM1][colM2];
        //traverse from first element of row to last element of row of matrix 1
        int i, j, k;
        for (i = 0; i < rowM1; i++) {
            //traverse from first element of column to last element of column of matrix 2
            for (j = 0; j < colM2; j++) {
                //traverse from first element of row to last element of row of matrix 1
                for (k = 0; k < rowM2; k++) {
                    result[i][j] += matrix1[i][k] * matrix2[k][j] ;
                    // Ex: 00 01 02       00 01    result[0][0] = 00*00 + 00*01 + 00*20 
                    //     10 11 12       10 11    result[0][1] = 00*01 + 01*11 + 02*20
                    //     20 21 22       20 21    ...
                    
                    // result[0][0] = matrix1[0][0] * matrix2[0][0]
                    //               +matrix1[0][1] * matrix2[1][0]    
                    //               +matrix1[0][2] + matrix2[2][0]
                    // result[0][1] = ...              
                }
            }
        }
        return result;
    }
}   
