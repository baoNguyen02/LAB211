/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Win
 */
public class Main {
    public static void main(String[] args){
        Calculator calculator = new Calculator();
        GetData getData = new GetData();
        Manager manager = new Manager();
        int choice;
        
        do{
            manager.DisplayMenu();
            choice = getData.getInt("Your choice: ", 1, 4);
            switch(choice){
                case 1:
                    System.out.println("-------- Addition --------");
                    int[][] matrix1 = manager.getMatrix1();
                    int[][] matrix2 = manager.getMatrix2(matrix1, choice);
                    int[][] result = calculator.additionMatrix(matrix1, matrix2);
                    manager.displayResult(matrix1, matrix2, result, choice);
                    break;
                
                case 2:
                    System.out.println("-------- Subtraction --------");
                    matrix1 = manager.getMatrix1();
                    matrix2 = manager.getMatrix2(matrix1, choice);
                    result = calculator.subtractionMatrix(matrix1, matrix2);
                    manager.displayResult(matrix1, matrix2, result, choice);
                    break;
                    
                case 3:
                    System.out.println("-------- Multiplication --------");                    
                    matrix1 = manager.getMatrix1();
                    matrix2 = manager.getMatrix2(matrix1, choice);
                    result = calculator.multiplicationMatrix(matrix1, matrix2);
                    manager.displayResult(matrix1, matrix2, result, choice);
                    break;
                    
                case 4:
                    System.exit(0);
                    break;
            }
            
        }while(true);
        
    }
}
