package j1.s.p0011;

public class Printer {

    public static void printBaseNumberInput() {
        System.out.println("1.Convert from binary");
        System.out.println("2.Convert from decimal");
        System.out.println("3.Convert from hexadecimal");
        System.out.print("Enter your choice: ");
    }

    public static void printBaseNumberOutput(int baseNumberInput) {
        switch (baseNumberInput) {
            case 1://input base is binary
                System.out.println("1.Convert to decimal");
                System.out.println("2.Convert to hexadecimal");
                System.out.print("Enter your choice: ");
                break;
            case 2://input base is decimal
                System.out.println("1.Convert to binary");
                System.out.println("2.Convert to hexadecimal");
                System.out.print("Enter your choice: ");
                break;
            case 3://input base is hexa
                System.out.println("1.Convert to decimal");
                System.out.println("2.Convert to binary");
                System.out.print("Enter your choice: ");
                break;
        }
    }

    public static void printOutputValue(int baseNumberInput, int baseNumberOutput, String inputValue, String convertedNumber) {
        String base1 = "";
        String base2 = "";
        switch (baseNumberInput) {
            case 1://input base is binary
                base1 = "(BIN)";
                if (baseNumberOutput == 1) {//output base is decimal
                    base2 = "(DEC)";
                } else {//output base is hexa
                    base2 = "(HEX)";
                }
                break;
            case 2://input base is decimal
                base1 = "(DEC)";
                if (baseNumberOutput == 1) {//output base is binary
                    base2 = "(BIN)";
                } else {//output base is hexa
                    base2 = "(HEX)";
                }
                break;
            case 3://input base is hexa
                base1 = "(HEX)";
                if (baseNumberOutput == 1) {//output base is decimal
                    base2 = "(DEC)";
                } else {//output base is binary
                    base2 = "(BIN)";
                }
                break;
        }
        System.out.println("=> " + inputValue + base1 + " = " + convertedNumber + base2);
    }

}