package j1.s.p0011;

import java.util.Scanner;

public class Inputter {

    public static int inputBaseNumberInput(int min, int max) {
        Printer.printBaseNumberInput();
        boolean check = false;
        int base = 0;
        Scanner input = new Scanner(System.in);
        //loop until input is valid
        while (check == false) {
            try {
                String numberInput = input.nextLine().trim();
                if (numberInput.isEmpty()) {//check empty input
                    System.out.println("Please enter a number");
                    System.out.print("Enter again: ");
                } else {
                    base = Integer.parseInt(numberInput);
                    if (base < min || base > max) {//number in valid range
                        System.out.println("Please enter a number in range from " + min + " to " + max);
                        System.out.print("Enter again: ");
                    } else {//input is valid
                        check = true;
                    }
                }
            } catch (NumberFormatException e) {//exception if input is a character
                System.out.println("Please enter an integer number!!!");
                System.out.print("Enter again: ");
            }
        }
        return base;
    }

    public static int inputBaseNumberOutput(int baseNumberInput, int min, int max) {
        Printer.printBaseNumberOutput(baseNumberInput);
        boolean check = false;
        int base = 0;
        Scanner input = new Scanner(System.in);
        //loop until input is valid
        while (check == false) {
            try {
                String numberInput = input.nextLine().trim();
                if (numberInput.isEmpty()) {//check empty input
                    System.out.println("Please enter a number");
                    System.out.print("Enter again: ");
                } else {
                    base = Integer.parseInt(numberInput);
                    if (base < min || base > max) {//number in valid range
                        System.out.println("Please enter a number in range from " + min + " to " + max);
                        System.out.print("Enter again: ");
                    } else {//input is valid
                        check = true;
                    }
                }
            } catch (NumberFormatException e) {//exception if input is a character
                System.out.println("Please enter an integer number!!!");
                System.out.print("Enter again: ");
            }
        }
        return base;
    }

    public static String inputValueToConvert(int baseNumberInput) {
        String number = "";
        switch (baseNumberInput) {
            case 1://input binary number
                number = inputBinary();
                break;
            case 2://input decimal number
                number = inputDecimal();
                break;
            case 3://input hexa number
                number = inputHexa();
                break;
        }
        return number;
    }

    public static String inputDecimal() {
        boolean check = false;
        String validDecimal = "[0-9]+";//valid range for decimal
        Scanner input = new Scanner(System.in);
        String number = "";
        System.out.print("Please enter decimal number: ");
        //loop until input is valid
        while (check == false) {
            number = input.nextLine().trim();
            if (number.isEmpty()) {//check empty input
                System.out.println("Please enter decimal number");
                System.out.print("Enter again: ");
            } else if (number.matches(validDecimal)) {//check valid number
                check = true;
            } else {//input number is not decimal number
                System.out.println("Please enter valid decimal number!!");
                System.out.print("Enter again: ");
            }
        }
        return number;
    }

    public static String inputBinary() {
        boolean check = false;
        String validBinary = "[0-1]+";//valid range for binary number
        Scanner input = new Scanner(System.in);
        String number = "";
        System.out.print("Please enter binary number: ");
        //loop until input is valid
        while (check == false) {
            number = input.nextLine().trim();
            if (number.isEmpty()) {//check empty input
                System.out.println("Please enter binary number");
                System.out.print("Enter again: ");
            } else if (number.matches(validBinary)) {//check valid number
                check = true;
            } else {//input number is not binary number
                System.out.println("Please enter valid binary number!!");
                System.out.print("Enter again: ");
            }
        }
        return number;
    }

    public static String inputHexa() {
        boolean check = false;
        String validHexa = "[0-9A-F]+";//valid range for hexa number
        Scanner input = new Scanner(System.in);
        String number = "";
        System.out.print("Please enter hexadecimal number: ");
        //loop until input is valid
        while (check == false) {//repeat until input is valid
            number = input.nextLine().trim().toUpperCase();
            if (number.isEmpty()) {//check empty input
                System.out.println("Please enter hexadecimal number");
                System.out.print("Enter again: ");
            } else if (number.matches(validHexa)) {//check valid number
                check = true;
            } else {//input number is not hexa number
                System.out.println("Please enter valid hexadecimal number!!");
                System.out.print("Enter again: ");
            }
        }
        return number;
    }

    public static boolean inputRepeatChoice() {
        System.out.print("Do you want to continue? (Y/N): ");
        Scanner input = new Scanner(System.in);
        String inputChoice;
        boolean repeatChoice = false;
        boolean check = false;
        //loop until input is valid
        while (check == false) {
            inputChoice = input.nextLine().trim().toUpperCase();
            if (inputChoice.matches("Y") || inputChoice.matches("N")) {//valid input Y/N
                check = true;
                if (inputChoice.matches("Y")) {//input is Y
                    repeatChoice = true;
                } else {//input is N
                    repeatChoice = false;
                }
            } else {//invalid input
                System.out.println("Please enter Y(y) or N(n)!!!");
                System.out.print("Enter again: ");
            }
        }

        return repeatChoice;
    }
}