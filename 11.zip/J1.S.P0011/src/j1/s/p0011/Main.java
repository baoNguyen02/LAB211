package j1.s.p0011;

public class Main {

    public static void main(String[] args) {
        boolean repeatChoice;
        do {
            //Step 1: input the base number input
            int baseNumberInput = Inputter.inputBaseNumberInput(1, 3);
            //Step 2: input the base number output
            int baseNumberOutput = Inputter.inputBaseNumberOutput(baseNumberInput, 1, 2);
            //Step 3: enter the input value to convert
            String inputValue = Inputter.inputValueToConvert(baseNumberInput);
            //Step 4: convert the number
            String convertedNumber = ConvertNumber.convertNumber(baseNumberInput, baseNumberOutput, inputValue);
            //Step 5: print output value           
            Printer.printOutputValue(baseNumberInput, baseNumberOutput, inputValue, convertedNumber);
            //Step 6: input if user wants to repeat
            repeatChoice = Inputter.inputRepeatChoice();
        } while (repeatChoice != false);

    }

}