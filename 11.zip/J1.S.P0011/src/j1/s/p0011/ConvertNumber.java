package j1.s.p0011;

import java.math.BigInteger;

public class ConvertNumber {

    public static String convertNumber(int baseNumberInput, int baseNumberOutput, String inputValue) {
        String number = "";
        switch (baseNumberInput) {
            case 1://input base is binary
                if (baseNumberOutput == 1) {//output base is decimal
                    number = convertNumberFromBinaryToDecimal(inputValue);
                } else {//output base is hexa
                    number = convertNumberFromBinaryToHexa(inputValue);
                }
                break;
            case 2://input base is decimal
                if (baseNumberOutput == 1) {//output base is binary
                    number = convertNumberFromDecimalToBinary(inputValue);
                } else {//output base is hexa
                    number = convertNumberFromDecimalToHexa(inputValue);
                }
                break;
            case 3://input base is hexa
                if (baseNumberOutput == 1) {//output base is decimal
                    number = convertNumberFromHexaToDecimal(inputValue);
                } else {//output base is hexa
                    number = convertNumberFromHexaToBinary(inputValue);
                }
                break;
        }

        return number;
    }

    public static String convertNumberFromDecimalToBinary(String decimal) {
        BigInteger divisor = new BigInteger(decimal);
        BigInteger base = BigInteger.valueOf(2);
        BigInteger check = BigInteger.valueOf(0);
        BigInteger remainder;
        BigInteger quotient;
        String reverseBinary = "";
        //loop to convert decimal number to binary(reversed)
        while (divisor != check) {
            quotient = divisor.divide(base);
            remainder = divisor.subtract(quotient.multiply(base));
            System.out.print(divisor + " : " + base + " = " + quotient + " remainder " + remainder + "\n");
            reverseBinary = reverseBinary + remainder;
            divisor = quotient;
        } 

        StringBuilder temp = new StringBuilder(reverseBinary);
        String binary = temp.reverse().toString();
        return binary;
    }

    public static String convertNumberFromDecimalToHexa(String decimal) {
        BigInteger divisor = new BigInteger(decimal);
        BigInteger base = BigInteger.valueOf(16);
        BigInteger check = BigInteger.valueOf(0);
        BigInteger remainder;
        BigInteger quotient;
        String reverseHexa = "";

        BigInteger a = BigInteger.valueOf(10);
        BigInteger b = BigInteger.valueOf(11);
        BigInteger c = BigInteger.valueOf(12);
        BigInteger d = BigInteger.valueOf(13);
        BigInteger e = BigInteger.valueOf(14);
        BigInteger f = BigInteger.valueOf(15);
        //loop to convert decimal number to hexa(reversed)
        while (divisor != check) {
            quotient = divisor.divide(base);
            remainder = divisor.subtract(quotient.multiply(base));
            System.out.print(divisor + " : " + base + " = " + quotient + " remainder " + remainder + "\n");
            //adding letters to hexa number
            if (remainder.compareTo(a) == 0) {       //adding A to hexa number
                reverseHexa = reverseHexa + "A";
            } else if (remainder.compareTo(b) == 0) {//adding B to hexa number
                reverseHexa = reverseHexa + "B";
            } else if (remainder.compareTo(c) == 0) {//adding C to hexa number
                reverseHexa = reverseHexa + "C";
            } else if (remainder.compareTo(d) == 0) {//adding D to hexa number
                reverseHexa = reverseHexa + "D";
            } else if (remainder.compareTo(e) == 0) {//adding E to hexa number
                reverseHexa = reverseHexa + "E";
            } else if (remainder.compareTo(f) == 0) {//adding F to hexa number
                reverseHexa = reverseHexa + "F";
            } else {//adding numbers to hexa number
                reverseHexa = reverseHexa + remainder;
            }
            divisor = quotient;
        }

        StringBuilder temp = new StringBuilder(reverseHexa);
        String hexa = temp.reverse().toString();
        return hexa;

    }

    public static String convertNumberFromBinaryToDecimal(String binary) {

        BigInteger decimal = BigInteger.valueOf(0);
        BigInteger base = BigInteger.valueOf(2);
        //traverse through every digit from left to right of a binary number
        int i,index;
        int p = 0;
        for (i = 0; i < binary.length(); i++) {
            BigInteger digit = BigInteger.valueOf(Character.getNumericValue(binary.charAt(i)));
            index = binary.length() - i - 1; //
            BigInteger temp =new BigInteger(binary);
            BigInteger tmp = new BigInteger(binary);
            BigInteger div = new BigInteger(binary);
            div = temp.divide(tmp);
            
            
            //BigInteger temp = base.pow(index); 
            //decimal = decimal.add(digit.multiply(temp));
            //printing the process 
            if (i == binary.length() - 1) {//printing the process of very last digit
                System.out.print(digit + "*2^" + index + " = ");
            } else {//printing the process of other digits
                System.out.print(digit + "*2^" + index + " + ");
            }
        }
        System.out.print(decimal + "\n");
        return String.valueOf(decimal);

    }
    public static String convertNumberFromBinaryToHexa(String binary) {
        String decimal = convertNumberFromBinaryToDecimal(binary);
        String hexa = convertNumberFromDecimalToHexa(decimal);
        return hexa;
    }

    public static String convertNumberFromHexaToDecimal(String hexa) {
        BigInteger decimal = BigInteger.valueOf(0);
        BigInteger digit;
        BigInteger base = BigInteger.valueOf(16);
        //traverse through every digit from left to right of a hexa number
        int i,index;
        for (i =0; i < hexa.length(); i++) {
                index = hexa.length() - i - 1;
            //getting "letter" digits 
            if (hexa.charAt(i) == 'A') {          //value for A
                digit = BigInteger.valueOf(10);
            } else if (hexa.charAt(i) == 'B') {   //value for B
                digit = BigInteger.valueOf(11);
            } else if (hexa.charAt(i) == 'C') {   //value for C
                digit = BigInteger.valueOf(12);
            } else if (hexa.charAt(i) == 'D') {   //valur for D
                digit = BigInteger.valueOf(13);
            } else if (hexa.charAt(i) == 'E') {   //value for E
                digit = BigInteger.valueOf(14);
            } else if (hexa.charAt(i) == 'F') {   //value for F
                digit = BigInteger.valueOf(15);
            } else {//value for numbers
                digit = BigInteger.valueOf(Character.getNumericValue(hexa.charAt(i)));
            }
            BigInteger temp = base.pow(index);
            decimal = decimal.add(digit.multiply(temp));
            //printing the process 
            if (i == hexa.length() - 1) {//printing the process of very last digit
                System.out.print(digit + "*16^" + index + " = ");
            } else {//printing the process of other digits
                System.out.print(digit + "*16^" + index + " + ");
            }
        }
        System.out.print(decimal + "\n");
        return String.valueOf(decimal);
    }

    public static String convertNumberFromHexaToBinary(String hexa) {
        String decimal = convertNumberFromHexaToDecimal(hexa);
        String binary = convertNumberFromDecimalToBinary(decimal);
        return binary;
    }
}