/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import Manager.Manager;
import Manager.Validation;

/**
 *
 * @author Win
 */
public class Menu {
    
    //print menu
    public static void menu(){
        System.out.println("========= Task program =========");
        System.out.println("1. Add Task.");
        System.out.println("2. Delete Task.");
        System.out.println("3. Display Task.");
        System.out.println("4. Exit.");
    }
    
    //chech choice from 1 to 4
    public static int getChoice(){
        Manager mt = new Manager();
        return Validation.inputIntLimit("Enter one option in above: ", 1, 4);
    }
    
    public static void display(){
        Manager mt = new Manager();
        int choice;
        while(true){
            menu();
            choice = getChoice();
            switch(choice){
                case 1:
                    System.out.println("----------------Add Task------------------");
                    String name = Validation.intputSring("Requirement Name: ", "input is not allowed to be empty");
                    int typeID = Validation.inputIntLimit("Task Type: ", 1, 4);
                    String date = Validation.inputDate("Date: ");
                    double from = Validation.inputDoublePlan("From: ");
                    double to = Validation.inputDoublePlan("To: ");
                    String assignee = Validation.intputSring("Assignee: ", "input is not allowed to be empty");
                    String reviewer = Validation.intputSring("Reviewer: ", "input is not allowed to be empty");
                    mt.addTask(name, typeID, date, from, to, assignee, reviewer);
                    break;
                case 2:
                    System.out.println("-------Del Task---------");
                    int idDelete = Validation.inputInt("ID: ");
                    mt.deleteTask(idDelete);
                    break;
                case 3:
                    System.out.println("----------------------------Task-------------------------------------");
                    mt.getDataTasks();
                    break;
                case 4:
                    return;
            }
        }
    }
}
