/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Manager;

import Object.Task;
import java.util.ArrayList;

/**
 *
 * @author Win
 */
public class Manager {
    ArrayList<Task> lt = new ArrayList<>();
    
    //allow user add information all task
    public int addTask(String name, int typeID  ,String date, double from, double to,
            String assignee, String reviewer) {
        int id = lt.size() + 1;
        if (checkDuplicate(name, typeID ,date, assignee, from, to)) {
            System.out.println("Duplicate!!!");
        }else if(from > to || to < from){
            System.out.println("fromPlan must greater than toPlan!!!");
        } else {
            Task newTask = new Task(id, name, typeID, date, from, to, assignee, reviewer);
            lt.add(newTask);  
            id++;
            System.out.println("Add successful!!");
        }
        return id;
    }
    
    //allow user delete a task
    public void deleteTask (int id){
        boolean check = true;
        int index = 0, i;
        for (i = 0; i < lt.size(); i++) {
            if(id==lt.get(i).getId()){
                lt.remove(i);
                check = false;
                System.out.println("Delete successful!!!");
                break;
            }
        }
        if(check){
            System.out.println("Id is not exist!");
        }
    }
    
    //allow user display information all task
    public void getDataTasks(){   
        if (lt.isEmpty()) {
            System.out.println("List task is empty!");
            return;
        } else{            
            System.out.format("%-7s%-20s%-12s%-15s%-7s%-15s%-15s\n", "Id", "Name", "Task Type", "Date", "Time", "Assignee", "Reviewer");
            //loop use to access each element of arraylist from begining to the end
            for (Task task : lt) {
                System.out.println(task);
            }
        }     
    }
    
    //check dupicate name, TypeID, date, Assignee, from, to
    public boolean checkDuplicate(String name, int typeID , String date, String assignee, double from, double to) {
        boolean isExist = false;
        //loop use to access each element of arraylist from begining to the end
        for (Task task : lt) {
            //compare name in list with date input and date, assignee in list and assignee input
            if (name.equalsIgnoreCase(task.getName())
                    && typeID == task.getId()
                    && date.equals(task.getDate()) 
                    && assignee.equals(task.getAssignee())
                    && from == task.getFrom()
                    && to == task.getTo()) {               
                isExist = true;                          
            }
        }
        return isExist;
    }
    
    
    
}
