/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Manager;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

/**
 *
 * @author Win
 */
public class Validation {
    public static Scanner sc = new Scanner(System.in);
    
    //check input int
    public static int inputInt(String msg) {
        String str;
        int choice;
         //loop until user input correct
        while (true){
            try {
                System.out.println(msg);
                str = sc.nextLine().trim();
                if (str.isEmpty()) {
                    System.out.println("choice is not allowed to be empty, pls re-entry!");
                    continue;
                }
                choice = Integer.parseInt(str);
                break;
            } catch (Exception e) {
                System.err.println("invalid amount, please input again");
            }
        }
        return choice;
    }
    
    //check user input int limit
    public static int inputIntLimit(String msg, int min, int max) {
        String str;
        int choice;
         //loop until user input correct
        do {
            try {
                System.out.print(msg);
                str = sc.nextLine().trim();
                if (str.isEmpty()) {
                    System.out.println("choice is not allowed to be empty, pls re-entry!");
                    continue;
                }
                choice = Integer.parseInt(str);
                if (choice < min || choice > max) {
                    throw new Exception();
                }
                break;
            } catch (Exception e) {
                System.out.println("choice must be an integer from " + min + " to " + max + ", pls re-entry !");
            }

        } while (true);
        return choice;
    }

   
    //check user input String
    public static String intputSring(String msg , String err){
        String name;
        String s = "";
        String str[];
        //loop until user input correct
        while (true) {            
            try {
                System.out.print(msg);
                name = sc.nextLine();
                if(!name.isEmpty()){
                    str = name.split("\\s++");
                    for (String x : str) {
                        name = String.valueOf(x.charAt(0)).toUpperCase() + x.substring(1).toLowerCase();
                        s = s + " " + name;
                    }
                    break;
                }
                throw new Exception();
            } catch (Exception e) {
                System.err.println(err);
            }
        }
        return s;
    }
    
    //check user input fromPlan double
    
    
    //check user input toPlan double
    public static double inputDoublePlan(String msg) {
        double n = 0;
         //loop until user input correct
        while (true) {
            try {
                System.out.print(msg);
                n = Double.parseDouble(sc.nextLine());
                if (n >= 8 && n <= 15.5) {
                    if(n % 0.5 == 0){
                        break;                       
                    }
                }
            } catch (Exception e) {
                System.err.println("invalid amount, please input again");
            }
        }
        return n;
    }
    
    //check user input Yes/No
    public static String inputYorN(String msg, String a, String b) {
        String choice;
         //loop until user input correct
        do {
            System.out.println(msg);
            choice = sc.nextLine().trim();
            if (choice.isEmpty()) {
                System.out.println("input is not allowed to be empty, pls re-entry !");
                continue;
            }
            if (!(choice.equalsIgnoreCase(a) || choice.equalsIgnoreCase(b))) {
                System.out.println("input must be " + a + "/" + b + ", pls re-entry !");
                continue;
            }
            break;
        } while (true);
        return choice;
    }
    
    //check input date
    public static String inputDate(String msg) {
        System.out.print(msg);
        Date now = new Date();
        SimpleDateFormat format = new SimpleDateFormat("dd-MM-yyyy");
        Scanner input = new Scanner(System.in);
        String result = "";
        while (true) {
            try {
                result = input.nextLine().trim();
                if (result.isEmpty()) {//empty input
                    System.err.println("Empty input!!");
                    System.out.print("Enter again: ");
                } else {//not empty input               
                    Date inputDate = format.parse(result);
                    String[] parts = result.split("-");
                    int day = Integer.parseInt(parts[0]);
                    int month = Integer.parseInt(parts[1]);
                    int year = Integer.parseInt(parts[2]);
                    if ((day < 1 || day > 31) && (month < 1 || month > 12)) {
                        //valid range for both month and day
                        System.err.println("Day must be in range 1-31 and month musts be in range 1-12!");
                        System.out.print("Enter again: ");
                    } else if (month < 1 || month > 12) {
                        //valid range for month
                        System.err.println("Month must be in range 1-12!");
                        System.out.print("Enter again: ");
                    } else if ((day < 1 || day > 31) && (month == 1 || month == 3 || month == 5 || month == 7 || month == 8 || month == 10 || month == 12)) {
                        //month 1,3,5,7,8,10,12 has day's range 1-31
                        System.err.println("Day must be in range 1-31 for month 1,3,5,7,8,10,12");
                        System.out.print("Enter again: ");
                    } else if ((day < 1 || day > 30) && (month == 4 || month == 6 || month == 9 || month == 11)) {
                        //month 4,6,9,11 has day's range 1-30
                        System.err.println("Day must be in range 1-30 for month 4,6,9,11");
                        System.out.print("Enter again: ");
                    } else if (month == 2 && ((year % 4 == 0 && year % 100 != 0) || year % 400 == 0) && (day < 1 || day > 29)) {
                        //february has 29 days in leap year
                        System.err.println("If month=2 and leap year then day must be in range 1-29");
                        System.out.print("Enter again: ");
                    } else if (month == 2 && !((year % 4 == 0 && year % 100 != 0) || year % 400 == 0) && (day < 1 || day > 28)) {
                        //february has 28 days in not a leap year
                        System.err.println("If month=2 and not a leap year then day must be in range 1-28");
                        System.out.print("Enter again: ");
                    } else if (inputDate.after(now)) {
                        //date cannot be in future
                        System.err.println("Date cannot be in future!");
                        System.out.print("Enter again: ");
                    } else {//valid date
                        return result;
                    }
                }
            } catch (NumberFormatException e) {
                System.err.println("dd-MM-yyyy must be integers ");
                System.out.print("Enter again: ");
            } catch (ParseException e) {
                System.err.println("Date must be in format dd-MM-yyyy");
                System.out.print("Enter again: ");
            }
        }
    }
}

    
