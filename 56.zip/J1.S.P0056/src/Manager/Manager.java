/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Manager;

import Object.SalaryHistory;
import Object.Worker;
import java.util.List;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Win
 */
public class Manager {
    double epsi  = 0.000001;
    
    List<SalaryHistory> shList = new ArrayList<>() ;
    List<Worker> wList = new ArrayList<>();
    Scanner sc = new Scanner(System.in);

    public Manager() {

    }
    
    //allow user add worker
    public  void inputWorker(){
        String ID , name , workLocation;
        int age;
        double salary;
        
        System.out.println("--------- Worker Management ---------");
        ID = inputStringID("Enter Code: ", "Code is Exist", 1);
        name = Validation.intputSring("Enter Name: ", "input is not allowed to be empty");
        age = Validation.inputInt("Enter Age: ", 18, 50);
        salary = Validation.inputDouble("Enter Salary: ", "Salary must be greater than 0",epsi,Double.MAX_VALUE);
        workLocation = Validation.intputSring("Enter work location: ", "input is not allowed to be empty");
        
        wList.add(new Worker(ID, name, age, salary, workLocation));
        System.out.println("Add Worker Succesfully!");
    }
    
    //allow user choose option add worker
    public void addWorker(){
        
        int n = Validation.inputInt("Enter Number Worker want to add: ", 0, 5);
        for (int i = 0; i < n; i++) {
            inputWorker();
        }
        String choice2;
        while (true) {
            choice2 = Validation.inputYorN("Do you want to continue (Y/N)? ", "Y", "N");
            if (choice2.equalsIgnoreCase("Y")) {
                inputWorker();
            } else {
                break;
            }
        }        
    }
    
    //allow user update worker
    public  void updateWorker(int mode) {
        String ID;
        ID = inputStringID("Enter Code: ", "Code must Exist in Database not Null", 2);
        for (int i = 0; i < wList.size(); i++) {
            if (wList.get(i).getID().equals(ID)) {
                System.out.println(wList.get(i));
            }
        }
        if(mode == 1){
            System.out.println("--------- Up Salary ---------");
        }else if(mode == 2){
            System.out.println("--------- Down Salary ---------");
        }
        double money = Validation.inputDouble("Enter Salary: ", "Salary must be greater than 0", epsi, Double.MAX_VALUE);
        Worker xxx = wExist(ID);
        double update = 0;
        String Status = "";
        if (mode == 1) {
            update = xxx.getSalary() + money;
            Status = "UP";            
        } else if (mode == 2) {
            if (xxx.getSalary() > money) {
                update = xxx.getSalary() - money;
                Status = "Down";
            } else {
                update = 0;
            }
        }
        xxx.setSalary(update);
        shList.add(new SalaryHistory(xxx.getID(), xxx.getName(), xxx.getAge(), xxx.getSalary(), Status, java.time.LocalDate.now()));
        System.out.println(xxx.toString());        
    }
    
    //allow user ger information 
    public  void getInformation(){
        display();
    }
    
    //allow user display information salaryHistory
    public  void display(){
        System.out.println("--------------------Display Information Salary-----------------------");
        //%s | %-8s | %2d | %-7.1f | %-4s | %-10s
        System.out.printf("%s | %-8s | %2s | %-7.1s | %-4s | %-10s\n", "Code", "Name", "Age","Salary","Status","Date");
        for (SalaryHistory o : shList) {
            System.out.println(o);
        }
    }
    
    
    //check user input Exist
    public Worker wExist(String ID) {
        for (Worker o : wList) {
            if (o.getID().equalsIgnoreCase(ID)) {
                return o;
            }
        }
        return null;
    }
    
     
    //check user input ID 
    public String inputStringID(String msg, String err, int choice) {
        String ID;
        //loop until user input correct
        while (true) {
            try {
                System.out.print(msg);
                ID = sc.nextLine().toUpperCase().trim();
                if (!ID.isEmpty()) {
                    if ((wExist(ID) == null && choice == 1) || wExist(ID) != null && choice == 2) {
                        break;
                    }
                }
                throw new Exception();
            } catch (Exception e) {
                System.err.println(err);
            }
        }
        return ID;
    }
}
