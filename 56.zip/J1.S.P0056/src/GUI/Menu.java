/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import Manager.Manager;
import Manager.Validation;
import Object.Worker;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Win
 */
public class Menu {
    
    //show menu
    public static void Menu() {
        System.out.println("========= Worker Managerment =========");
        System.out.println("    1.Add Worker");
        System.out.println("    2.Up salary");
        System.out.println("    3.Down salary");
        System.out.println("    4.Display information salary");
        System.out.println("    5.Exit");
    }
    
    //alow user choose option
    public static int getChoice() {
        Manager mw = new Manager();
        return Validation.inputInt("Enter one option in above : ", 1, 5);
    }
    
    //display option
    public static void display() {
        Manager mw = new Manager();      
     
        int choice;
        while (true) {
            Menu();
            choice = getChoice();
            switch (choice) {
                case 1:
                    mw.addWorker();
                    break;
                case 2:
                    mw.updateWorker(1);
                    break;
                case 3:
                    mw.updateWorker(2);
                    break;
                case 4:
                    mw.getInformation();
                    break;
                case 5:
                    return;
            }
        }
    }
}
