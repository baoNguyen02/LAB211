/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Manager;

import Object.Student;
import java.util.Scanner;

/**
 *
 * @author Win
 */
public class Validation {
    public static Scanner sc = new Scanner(System.in);
    
    //check user input int limit
    public static int inputInt(String msg, int min, int max) {
        String str;
        int choice;
         //loop until user input correct
        do {
            try {
                System.out.print(msg);
                str = sc.nextLine().trim();
                if (str.isEmpty()) {
                    System.out.println("choice is not allowed to be empty, pls re-entry!");
                    continue;
                }
                choice = Integer.parseInt(str);
                if (choice < min || choice > max) {
                    throw new Exception();
                }
                break;
            } catch (Exception e) {
                System.out.println("choice must be an integer from " + min + " to " + max + ", pls re-entry !");
            }

        } while (true);
        return choice;
    }

   
    //check user input String 
    public static String inputSring(String msg , String err){
        String name;
        String s = "";
        String str[];
        //loop until user input correct
        while (true) {            
            try {
                System.out.print(msg);
                name = sc.nextLine();
                if(!name.isEmpty()){
                    str = name.split("\\s++");
                    for (String x : str) {
                        name = String.valueOf(x.charAt(0)).toUpperCase() + x.substring(1).toLowerCase();
                        s = s + " " + name;
                    }
                    break;
                }
                throw new Exception();
            } catch (Exception e) {
                System.err.println(err);
            }
        }
        return s;
    }
    
    //check user input double
    public static double inputDouble(String msg, String err , double min , double max) {
        double n;
         //loop until user input correct
        while (true) {
            try {
                System.out.print(msg);
                n = Double.parseDouble(sc.nextLine());
                if (n < min) {
                    System.out.println(err + " is greater than equal zero");
                }else if(n > max){
                    System.out.println(err + " is less than equal ten");
                }else{
                    break;
                }
            } catch (NumberFormatException e) {
                System.err.println(err + " is digit.");
            }
        }
        return n;
    }
    
    //check user input Yes/No
    public static String inputYorN(String msg, String a, String b) {
        String choice;
         //loop until user input correct
        do {
            System.out.println(msg);
            choice = sc.nextLine().trim();
            if (choice.isEmpty()) {
                System.out.println("input is not allowed to be empty, pls re-entry !");
                continue;
            }
            if (!(choice.equalsIgnoreCase(a) || choice.equalsIgnoreCase(b))) {
                System.out.println("input must be " + a + "/" + b + ", pls re-entry !");
                continue;
            }
            break;
        } while (true);
        return choice;
    }
}
    
