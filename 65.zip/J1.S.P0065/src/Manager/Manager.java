/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Manager;

import Object.Student;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 *
 * @author Win
 */
public class Manager {   
    List<Student> list = new ArrayList<>();
    
    public void createStudent(){
        
        System.out.println("====== Management Student Program ======");
        String name, classes;
        double math, physical, chemistry;
        
        while(true){
            name = Validation.inputSring("Name: ", "input is not allowed to be empty");          
            classes = Validation.inputSring("Classes: ", "input is not allowed to be empty");
            math = Validation.inputDouble("Math: ", "Math", 0, 10);
            chemistry = Validation.inputDouble("Chemistry: ", "Chemistry", 0, 10);
            physical = Validation.inputDouble("Physical: ", "Physical", 0, 10);;
            list.add(new Student(name, classes, math, physical, chemistry));             
            String choice = Validation.inputYorN("Do you want to enter more student information?(Y/N): ", "Y", "N");
            if(choice.equalsIgnoreCase("N")){
                break;
            }
        }
        averageStudent();
        HashMap<String, Double> mapStudent = getPercentTypeStudent();
        System.out.println("--------Classification Info -----");
        mapStudent.forEach((key,value)-> System.out.println(key+": "+value+"%"));
    }
    public void averageStudent(){
        int index = 1;
        for (Student o : list) {
            System.out.println("------ Student"+index+" Info ------");
            o.display();
            index++;
        }
    }
    public HashMap<String, Double> getPercentTypeStudent(){
        HashMap<String, Double> hashMap = new HashMap<>();
        int countA = 0;
        int countB = 0;
        int countC = 0;
        int countD = 0;
        for (Student o : list) {
            if(o.getAVG()>=7.5){
                countA++;
            }else if(o.getAVG()>=6){
                countB++;
            }else if(o.getAVG() >=4){
                countC++;
            }else{
                countD++;
            }
        }
        int totalStudent = list.size(); 
        hashMap.put("A", 100.0*countA/totalStudent);
        hashMap.put("B", 100.0*countB/totalStudent);
        hashMap.put("C", 100.0*countC/totalStudent);
        hashMap.put("D", 100.0*countD/totalStudent);
        return hashMap;
    }
}
