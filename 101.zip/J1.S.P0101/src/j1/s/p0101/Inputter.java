/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package j1.s.p0101;

/**
 *
 * @author Win
 */
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Scanner;

/**
 *
 * @author admin    
 * .
 */
public class Inputter {

    public static int inputNumberInRange(int min, int max, int mode) {
        Scanner input = new Scanner(System.in);
        int result = 0;
        //loop for valid input
        while (true) {
            try {
                String choice = input.nextLine().trim();
                if (choice.isEmpty() && mode == 1) {//check empty input
                    System.err.println("Empty input");
                    System.out.print("Enter again: ");
                }
                else if(choice.isEmpty() && mode == 0){
                    break;
               }
                else {
                    result = Integer.parseInt(choice);
                    if (result < min || result > max) {//number not in valid range
                        System.err.println("Please enter a number in range from " + min + " to " + max + "!!");
                        System.out.print("Enter again: ");
                    } else {//number in valid range
                        return result;//break the loop
                    }
                }
            } catch (NumberFormatException e) {//exception if input is a character
                System.err.println("Please enter an integer number!!!");
                System.out.print("Enter again: ");
            }
        }
        return result;
    }

    public static int inputPositiveNumber(String msg, int mode) {
        Scanner input = new Scanner(System.in);
        int result = 0;
        System.out.print(msg);
        //loop for valid number
        while (true) {
            try {
                String temp = input.nextLine().trim();
                if (temp.isEmpty() && mode == 0) {//check empty input
                    System.err.println("Empty input!");
                    System.out.print("Enter again: ");
                } else {
                    result = Integer.parseInt(temp);
                    if (result <= 0) {//input number not positive
                        System.err.println("Please enter positive number!");
                        System.out.print("Enter again: ");
                    } else {//valid input
                        return result;
                    }
                }
            } catch (NumberFormatException e) {//user enter a character
                System.err.println("Please enter an integer number!");
                System.out.print("Enter again: ");
            }

        }
    }

    public static String inputName(String msg, int mode) {
        //name contains only letters
        String validName = "[a-zA-Z]+|$";
        Scanner input = new Scanner(System.in);
        String result = "";
        System.out.print(msg);
        //loop for valid name
        while (true) {
            result = input.nextLine().trim();
            if (result.isEmpty() && mode == 1) {//check empty input
                System.err.println("Empty input!");
                System.out.print("Enter again: ");
            } else if (!result.matches(validName)) {//name doesn't contains only letters
                System.err.println("Please use only letters!");
                System.out.print("Enter again: ");
            } else {//valid input
                return result;
            }
        }
    }

    public static String inputPhone(String msg, int mode) {
        //phone contains only numbers
        String validName = "[0-9]+|$";
        Scanner input = new Scanner(System.in);
        String result = "";
        System.out.print(msg);
        //loop for valid phone
        while (true) {
            result = input.nextLine().trim();
            if (result.isEmpty() && mode == 1) {//check empty input
                System.err.println("Empty input!");
                System.out.print("Enter again: ");
            } else if (!result.matches(validName)) {//phone doesn't contains only numbers
                System.err.println("Please use only numbers!");
                System.out.print("Enter again: ");
            } else {//valid input
                return result;
            }
        }
    }

    public static String inputEmail(String msg, int mode) {
        System.out.print(msg);
        String validEmail = "^[a-zA-Z][\\w-]+@([\\w]+\\.[\\w]+|[\\w]+\\.[\\w]{2,}\\.[\\w]{2,})$|$";
        String result = "";
        Scanner input = new Scanner(System.in);
        //loop for valid email
        while (true) {
            result = input.nextLine().trim();
            if (result.isEmpty() && mode == 1) {//check empty input
                System.err.println("Empty input!");
                System.out.print("Enter again: ");                                   
            }else if(!result.matches(validEmail)){
                System.err.println("Please enter valid email!");
                System.out.print("Enter again: ");
            }
            else {
                return result;
            }
        }
    }

    public static String inputDate(String msg, int mode) {
        System.out.print(msg);
        Date now = new Date();
        SimpleDateFormat format = new SimpleDateFormat("dd-MM-yyyy");
        Scanner input = new Scanner(System.in);
        String result = "";
        String validDate = "\\d{1,2}[-]\\d{1,2}[-]\\d{4}|$";
        while (true) {
            result = input.nextLine().trim();
            if (result.isEmpty() && mode == 1) {//empty input
                System.err.println("Empty input!!");
                System.out.print("Enter again: ");
            }
            else if(!result.matches(validDate)){
                 System.err.println("Please enter valid date! dd-MM-yyyy");
                 System.out.print("Enter again: ");
            }else{
                return result;
            }    
        
        }
    }

    public static String inputSex(String msg, int mode) {
        System.out.println(msg);
        System.out.println("1. Male");
        System.out.println("2. Female");
        System.out.println("3. Other");
        System.out.print("Your choice: ");
        int choice = inputNumberInRange(1, 3, mode);
        if(choice == 0){
            return null;
        } else if (choice == 1) {
            return "Male";
        } else if(choice == 2) {
            return "Female";
        } else {
            return "Other";
        }
    }

    public static double inputDouble(String msg, int mode) {
        Scanner input = new Scanner(System.in);
        double result = -1;
        System.out.print(msg);
        //loop for valid number
        while (true) {
            try {
                String temp = input.nextLine().trim();
                if (temp.isEmpty() && mode == 1) {//check empty input
                    System.err.println("Empty input!");
                    System.out.print("Enter again: ");
                }
                if (temp.isEmpty() && mode == 0) {//check empty input
                    break;
                }
                else {
                    result = Double.parseDouble(temp);
                    if (result <= 0) {//input number not positive
                        System.err.println("Please enter positive number!");
                        System.out.print("Enter again: ");
                    }
                    else {//valid input
                        return result;
                    }
                }
            } catch (NumberFormatException e) {//user enter a character
                System.err.println("Please enter an double number!");
                System.out.print("Enter again: ");
            }

        }
        return result;
    }

    public static String inputString(String msg, int mode) {
        Scanner input = new Scanner(System.in);
        String result = "";
        System.out.print(msg);
        //loop for valid string
        while (true) {
            result = input.nextLine().trim();
            if (result.isEmpty() && mode == 1) {//check empty input
                System.err.println("Empty input");
                System.out.print("Enter again: ");
            } else {//valid string
                return result;
            }
        }
    }

}
