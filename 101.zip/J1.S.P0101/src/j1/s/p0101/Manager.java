package j1.s.p0101;


import java.util.ArrayList;
import java.util.Collections;

public class Manager {

    public void displayMenu() {
        System.out.println("------Employees Management-------");
        System.out.println("1. Add employees");
        System.out.println("2. Update employees");
        System.out.println("3. Remove employees");
        System.out.println("4. Search employees");
        System.out.println("5. Sort employees by salary");
        System.out.println("6. Exit");
        System.out.print("Enter your choice: ");
    }
    
    ArrayList<Employee> employeeList = new ArrayList<>();
    ArrayList<Employee> foundEmployeeList = new ArrayList<>();
    
    public void addEmployees() {
        System.out.println("------Add employees---------");
        int ID;
        //loop to enter valid ID that doesn't exist
        while (true) {
            ID = Inputter.inputPositiveNumber("Enter employee ID: ", 1);
            if (checkIDExist(ID)) {
                System.err.println("ID already exist!");
            } else {
                break;
            }
        }
        String firstName = Inputter.inputName("Enter employee first name: ", 1);
        String lastName = Inputter.inputName("Enter employee last name: ", 1);
        String phone = Inputter.inputPhone("Enter employee phone: ", 1);
        String email = Inputter.inputEmail("Enter employee email: ", 1);
        String address = Inputter.inputString("Enter employee address: ", 1);
        String dob = Inputter.inputDate("Enter employee date of birth: ", 1);
        String sex = Inputter.inputSex("Choose employee sex: ", 1);
        double salary = Inputter.inputDouble("Enter employee salary: ", 1);
        String agency = Inputter.inputString("Enter employee agency: ", 1);
        employeeList.add(new Employee(ID, firstName, lastName, phone, email, address, dob, sex, salary, agency));
        System.out.println("Add employee successfully");
    }

    public void updateEmployees() {
        //check if employee list is empty
        if (employeeList.isEmpty()) {
            System.out.println("Employee list is empty");
            return;
        }
        System.out.println("------Update employee----------");
        int ID;
        //loop to enter valid existing ID
        while (true) {
            ID = Inputter.inputPositiveNumber("Enter employee ID to update: ", 1);
            if (!checkIDExist(ID)) {
                System.err.println("ID doesn't exist!");
            } else {
                break;
            }
        }
        Employee employee = findEmployeeByID(ID);
        
        String newFirstName = Inputter.inputName("Enter new employee first name: ", 0);
        String newLastName = Inputter.inputName("Enter new employee last name: ", 0);
        String newPhone = Inputter.inputPhone("Enter new employee phone: ", 0);
        String newEmail = Inputter.inputEmail("Enter new employee email: ", 0);
        String newAddress = Inputter.inputString("Enter new employee address: ", 0);
        String newDob = Inputter.inputDate("Enter new employee date of birth: ", 0);
        String newSex = Inputter.inputSex("Choose new employee sex: ", 0);
        double newSalary = Inputter.inputDouble("Enter new employee salary: ", 0);
        String newAgency = Inputter.inputString("Enter new employee agency: ", 0);
        
        if(!newFirstName.isEmpty()){
        employee.setFirstName(newFirstName);}
        if(!newLastName.isEmpty()){
        employee.setLastName(newLastName);}
        if(!newPhone.isEmpty()){
        employee.setPhone(newPhone);}
        if(!newEmail.isEmpty()){
        employee.setEmail(newEmail);}
        if(!newAddress.isEmpty()){
        employee.setAddress(newAddress);}
        if(!newAddress.isEmpty()){
        employee.setDob(newDob);}
        if(newSex != null){
        employee.setSex(newSex);}
        if(newSalary != -1){
        employee.setSalary(newSalary);}
        if(!newAgency.isEmpty()){
        employee.setAgency(newAgency);}
        System.out.println("Update successfully");
    }

    public void removeEmployees() {
        //check if employee list is empty
        if (employeeList.isEmpty()) {
            System.out.println("Employee list is empty");
            return;
        }
        System.out.println("------Remove employees--------");
        int ID;
        //loop to enter valid existing ID
        while (true) {
            ID = Inputter.inputPositiveNumber("Enter employee ID to remove: ", 1);
            if (!checkIDExist(ID)) {
                System.err.println("ID doesn't exist!");
            } else {
                break;
            }
        }
        Employee employee = findEmployeeByID(ID);
        employeeList.remove(employee);
        System.out.println("Remove successfully");
    }

    public void searchEmployees() {
        //check if employee list is empty
        if (employeeList.isEmpty()) {
            System.out.println("Employee list is empty");
            return;
        }
        System.out.println("-------Search empployee--------");
        String name;
        //loop to enter valid existing name 
        while (true) {
            name = Inputter.inputName("Enter name or part of name to find employee: ", 1);
            if (!checkNameExist(name)) {
                System.err.println("Name doesn't exist!");
            } else {
                break;
            }
        }
        ArrayList<Employee> foundEmployeeList = findEmployeeByName(name);
        System.out.printf("%-5s%-12s%-12s%-15s%-25s%-25s%-15s%-10s%-15s%s\n", "ID", "First Name", "Last Name", "Phone", "Email", "Address", "DOB", "Sex", "Salary", "Agency");
        //traverse through employee found list and print them
        for (int i = 0; i < foundEmployeeList.size(); i++) {
            int ID = foundEmployeeList.get(i).getID();
            String firstName = foundEmployeeList.get(i).getFirstName();
            String lastName = foundEmployeeList.get(i).getLastName();
            String phone = foundEmployeeList.get(i).getPhone();
            String email = foundEmployeeList.get(i).getEmail();
            String address = foundEmployeeList.get(i).getAddress();
            String dob = foundEmployeeList.get(i).getDob();
            String sex = foundEmployeeList.get(i).getSex();
            double salary = foundEmployeeList.get(i).getSalary();
            String agency = foundEmployeeList.get(i).getAgency();
            System.out.printf("%-5s%-12s%-12s%-15s%-25s%-25s%-15s%-10s%-15s%s\n", ID, firstName, lastName, phone, email, address, dob, sex, salary, agency);
            foundEmployeeList.remove(foundEmployeeList.get(i));            
        }
        
    }

    public void sortEmployeesBySalary() {
        //check if employee list is empty
        if (employeeList.isEmpty()) {
            System.out.println("Employee list is empty");
            return;
        }
        System.out.println("------Sort employees by salary------");
        Collections.sort(employeeList);
        System.out.printf("%-5s%-12s%-12s%-15s%-25s%-25s%-15s%-10s%-15s%s\n", "ID", "First Name", "Last Name", "Phone", "Email", "Address", "DOB", "Sex", "Salary", "Agency");
        //traverse through sorted employee list and print them
        for (int i = 0; i < employeeList.size(); i++) {
            int ID = employeeList.get(i).getID();
            String firstName = employeeList.get(i).getFirstName();
            String lastName = employeeList.get(i).getLastName();
            String phone = employeeList.get(i).getPhone();
            String email = employeeList.get(i).getEmail();
            String address = employeeList.get(i).getAddress();
            String dob = employeeList.get(i).getDob();
            String sex = employeeList.get(i).getSex();
            double salary = employeeList.get(i).getSalary();
            String agency = employeeList.get(i).getAgency();
            System.out.printf("%-5s%-12s%-12s%-15s%-25s%-25s%-15s%-10s%-15s%s\n", ID, firstName, lastName, phone, email, address, dob, sex, salary, agency);
        }
    }

    public boolean checkIDExist(int ID) {
        //traverse through employee list and check if ID already exist
        for (int i = 0; i < employeeList.size(); i++) {
            if (employeeList.get(i).getID() == ID) {
                return true;
            }
        }
        return false;
    }

    public Employee findEmployeeByID(int ID) {
        //traverse through employee list and find employee with this ID
        for (int i = 0; i < employeeList.size(); i++) {
            if (ID == employeeList.get(i).getID()) {
                return employeeList.get(i);
            }
        }
        return null;
    }

    public  boolean checkNameExist(String name) {
        //traverse through employee list and check if name exists
        for (int i = 0; i < employeeList.size(); i++) {
            if (employeeList.get(i).getFirstName().toLowerCase().contains(name.toLowerCase())
                    || employeeList.get(i).getLastName().toLowerCase().contains(name.toLowerCase())) {
                return true;
            }
        }
        return false;
    }

    public ArrayList<Employee> findEmployeeByName(String name) {
        
        //traverse through employee list and get all employees with this name
        for (int i = 0; i < employeeList.size(); i++) {
            if (employeeList.get(i).getFirstName().toLowerCase().contains(name.toLowerCase())
                    || employeeList.get(i).getLastName().toLowerCase().contains(name.toLowerCase())) {
                foundEmployeeList.add(employeeList.get(i));
            }
        }
        return foundEmployeeList;
    }

}