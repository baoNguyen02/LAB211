package j1.s.p0101;

import java.util.ArrayList;

public class Main {

    
    public static void main(String[] args) {
        
        Manager Manager = new Manager();
        int choice =0;
        //Step 1: display menu
        while (choice!=6){
        Manager.displayMenu();
        //Step 2: input user choice
        choice = Inputter.inputNumberInRange(1, 6, 1);
        //Step 3: run option based on choice
        switch (choice){
            //Option 1: Add employees
            case 1: Manager.addEmployees();break;
            //Option 2: Update employees
            case 2: Manager.updateEmployees();break;
            //Option 3: Remove employees
            case 3: Manager.removeEmployees();break;
            //Option 4: Search employees
            case 4: Manager.searchEmployees();break;
            //Option 5: Sort employees by salary
            case 5: Manager.sortEmployeesBySalary();break;
            //Option 6: Exit
            case 6: break;
        }
    }
}
    
}