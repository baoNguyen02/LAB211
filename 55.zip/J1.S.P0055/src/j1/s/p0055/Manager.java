/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package j1.s.p0055;

import java.util.ArrayList;

/**
 *
 * @author Win
 */
public class Manager {
    
    //display menu
    public static int menu(){
        System.out.println("1. Add doctor");
        System.out.println("2. Update doctor");
        System.out.println("3. Delete doctor");
        System.out.println("4. Search doctor");
        System.out.println("5. Exit");
        System.out.print("Enter your choice: ");
        int choice = Validation.CheckInputIntLimit(1, 5);
        return choice;        
    }
    
    //alow user add doctor
    public void addDoctor(ArrayList<Doctor> ld){
        System.out.println("Enter code: ");
        String code = Validation.checkInputString();
        //check code exist or not
        if(Validation.checkCodeExits(ld, code)){
            System.err.println("Doctor code already exist");
            return;
        }
        System.out.print("Enter name: ");
        String name = Validation.checkInputString();
        System.out.print("Enter specialization: ");
        String specialization = Validation.checkInputString();
        System.out.print("Enter availability: ");
        int availability = Validation.checkInputInt();
        //check work duplicate
        
        ld.add(new Doctor(code, name, specialization, availability));
        System.err.println("Add successful");
    }
    
    //allow user update doctor
    public void updateDoctor(ArrayList<Doctor> ld){
       
        System.out.println("Enter code: ");
        String code = Validation.checkInputString();
        //Check code exist or not
        if(!Validation.checkCodeExits(ld, code)){
            System.err.println("Doctor code does not exist");
            return;
        }
       
        Doctor doctor = getDoctorByCode(ld, code);
        System.out.println("Enter name: ");
        String name = Validation.checkInputStringUpdate();
        System.out.println("Enter specialization: ");
        String specialization = Validation.checkInputStringUpdate();
        System.out.println("Enter availability: ");
        Integer availability = Validation.checkInputIntUpdate();
       //Check user change information or not
      
       if(!name.isEmpty()){
       doctor.setName(name);}
       if(!specialization.isEmpty()){
       doctor.setSpecialization(specialization);}
       if(availability != null){
       doctor.setAvailability(availability);}
       System.err.println("Update successful");
    }
    
    //allow user delete doctor
    public void deleteDoctor(ArrayList<Doctor> ld) {
        System.out.print("Enter code: ");
        String code = Validation.checkInputString();
        Doctor doctor = getDoctorByCode(ld, code);
        if (doctor == null) {
            System.err.println("Not found doctor.");
            return;
        } else {
            ld.remove(doctor);
        }
        System.err.println("Delete successful.");
    }
    
    //allow user search docor
    public void searchDoctor(ArrayList<Doctor> ld){
        System.out.println("Enter name ");
        String nameSearch = Validation.checkInputString();
        ArrayList<Doctor> listFoundByName = listFoundByName(ld, nameSearch);
        if(listFoundByName.isEmpty()){
            System.err.println("List empty.");
        }else{
            System.out.printf("%-10s%-15s%-25s%-20s\n", "code", "name"
            ,"Specialization", "Avalability");
            for (Doctor doctor : listFoundByName) {
                System.out.printf("%-10s%-15s%-25s%-20s\n", doctor.getCode(), doctor.getName()
            ,doctor.getSpecialization(), doctor.getAvailability());
            }
        }        
    }
    
    
    //get doctor by code
    public Doctor getDoctorByCode(ArrayList<Doctor> ld, String code) {
        for (Doctor doctor : ld) {
            if(doctor.getCode().equalsIgnoreCase(code)){
                return doctor;
            }    
        }
        return null;
    }
    
    //get list by name 
    public ArrayList<Doctor> listFoundByName(ArrayList<Doctor> ld, String name){
        ArrayList<Doctor> listFoundByName = new ArrayList<>();
        for (Doctor doctor : ld) {
            if(doctor.getName().contains(name)){
                listFoundByName.add(doctor);
            }
        }
        return listFoundByName;
    }
    
}
