/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package j1.s.p0055;

import java.util.ArrayList;

/**
 *
 * @author Win
 */
public class Main {
    public static void main(String[] args){
        ArrayList<Doctor> ld = new ArrayList<>();
        Manager Manager = new Manager();
        //loop until user want to exist
        while(true){
            int choice = Manager.menu();
            switch(choice){
                case 1:
                    Manager.addDoctor(ld);
                    break;
                case 2:
                    Manager.updateDoctor(ld);
                    break;
                case 3:
                    Manager.deleteDoctor(ld);
                    break;
                case 4:
                    Manager.searchDoctor(ld);
                    break;
                case 5:
                    return;
            }
        }
    }
}
