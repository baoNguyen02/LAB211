/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package j1.s.p0055;

import java.util.ArrayList;
import java.util.Scanner;


/**
 *
 * @author Win
 */
public class Validation {
    
    private static final Scanner sc = new Scanner(System.in);
    
    //Check user input number limit 
    public static int CheckInputIntLimit(int min, int max){
        // loop until user input correct
        while(true){
            try {
                int result = Integer.parseInt(sc.nextLine().trim());
                if(result < min || result > max){
                    throw new NumberFormatException();
                }
                return result;
            } catch (NumberFormatException e) {
                System.err.println("Please input number in rage [" +min+", " +max+ "}");
                System.out.print("Enter again: ");
            }
        }
    }
    
    //Check user input String
     static String checkInputString(){
        // loop until user input correct
        while(true){
            String result = sc.nextLine().trim();
            if(result.isEmpty()){
                System.err.println("Not empty");
                System.out.println("Enter again: "); 
            }else{
                return result;
            }
        }
    }

    //Check user input String update
     static String checkInputStringUpdate(){
        // loop until user input correct
        while(true){
            String result = sc.nextLine().trim();
            return result;
            
        }
    }
    
    //Check user input String
   
      public static int checkInputInt(){
        // loop until user input correct
        while(true){
            try {
                
                int result = Integer.parseInt(sc.nextLine());
                return result;
               
            } catch (NumberFormatException e) {
                System.err.println("Please input number integer.");
                System.out.print("Enter again: ");
            }
        }
       
    
        
    }
     public static Integer checkInputIntUpdate(){
        // loop until user input correct
        
        Integer result = null;
        String input;
        while(true){
            
            try {
                
                input = sc.nextLine();
                if(input.trim().equals("")){
                    break;
                }
                result = Integer.parseInt(input);    
                
               
            } catch (NumberFormatException e) {
                System.err.println("Please input number integer.");
                System.out.print("Enter again: ");
            }
        }
       
        return result;
        
    }
    
    //Check user input yes/ no
    public static boolean checkInputYN(){
        // loop util user input correct
        while(true){
            String result = checkInputString();
            //return true if user  input Y/y
            if(result.equalsIgnoreCase("Y")){
                return true;
            }
            //return false if user input N/n
            if(result.equalsIgnoreCase("N")){
                return false;
            }
            System.err.println("Please input y/Y or n/N");
            System.out.println("Enter again: ");
        }
    }
    
    //Check code exits or not
    public static boolean checkCodeExits(ArrayList<Doctor> ld, String code){
        //check from first to last list doctor
        for (Doctor doctor : ld) {
            if(code.equalsIgnoreCase(doctor.getCode())){
                return true;
            }
        }
        return false;
    }
    
    //Check doctor duplicate
    public static boolean checkDuplicate(ArrayList<Doctor> ld, String code,
            String name, String specialization, int availability){
        //Check from first to last list doctor
        for (Doctor doctor : ld) {
            if(code.equalsIgnoreCase(doctor.getCode())
                    && name.equalsIgnoreCase(doctor.getName())
                    && specialization.equalsIgnoreCase(doctor.getSpecialization())
                    && availability == doctor.getAvailability()){
                return true;
            }
        }
        return false;
    }
    
    //Check user change information or not
    public static boolean checkChangeInfo(Doctor doctor, String code,
            String name, String specialization, int availability){
        if(code.equalsIgnoreCase(doctor.getCode())
                    && name.equalsIgnoreCase(doctor.getName())
                    && specialization.equalsIgnoreCase(doctor.getSpecialization())
                    && availability == doctor.getAvailability()){
                return true;
        }
        return false;
    }
    
        
}
